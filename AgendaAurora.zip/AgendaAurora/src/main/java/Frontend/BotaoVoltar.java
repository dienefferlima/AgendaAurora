/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Frontend;

/**
 *
 * @author diene
 */
public class BotaoVoltar {
    public static void main(String[] args) {
        FrmLogin login = new FrmLogin();
        login.setVisible(true);
    }

    // Método estático para trocar de tela (por exemplo: para login)
    public static void mostrarTelaLogin() {
        FrmLogin login = new FrmLogin();
        login.setVisible(true);
    }
}

    

