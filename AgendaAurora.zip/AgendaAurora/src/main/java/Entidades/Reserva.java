/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

public class Reserva {
    private String unidade;
    private String auditorio;
    private String data;
    private String horaInicial;
    private String horaFinal;
    private String usuario;
    private String observacoes;
    
    public Reserva() {
    }

    public Reserva(String unidade, String auditorio, String data, String horaInicial, String horaFinal, String usuario, String observacoes) {
        this.unidade = unidade;
        this.auditorio = auditorio;
        this.data = data;
        this.horaInicial = horaInicial;
        this.horaFinal = horaFinal;
        this.usuario = usuario;
        this.observacoes = observacoes;
    }

    // Getters
    public String getUnidade() { return unidade; }
    public String getAuditorio() { return auditorio; }
    public String getData() { return data; }
    public String getHoraInicial() { return horaInicial; }
    public String getHoraFinal() { return horaFinal; }
    public String getUsuario() { return usuario; }
    public String getObservacoes() { return observacoes; }

    // Setters
    public void setUnidade(String unidade) { this.unidade = unidade; }
    public void setAuditorio(String auditorio) { this.auditorio = auditorio; }
    public void setData(String data) { this.data = data; }
    public void setHoraInicial(String horaInicial) { this.horaInicial = horaInicial; }
    public void setHoraFinal(String horaFinal) { this.horaFinal = horaFinal; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
}

/**
 *
 * @author diene
 */

