/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Entidades;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author diene
 */
public class AgendaAurora {

    public static List<Reserva> listaReservas = new ArrayList<>();
    }
